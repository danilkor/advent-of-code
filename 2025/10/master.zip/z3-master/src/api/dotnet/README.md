# Z3 Nuget Package

For more information see [the Z3 github page](https://github.com/z3prover/z3.git)
