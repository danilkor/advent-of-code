/**
Copyright (c) 2012-2014 Microsoft Corporation
   
Module Name:

    ReSort.java

Abstract:

Author:

    @author Christoph Wintersteiger (cwinter) 2012-03-15

Notes:
    
**/ 

package com.microsoft.z3;

/**
 * A Regular expression sort
 **/
public class ReSort<R extends Sort> extends Sort
{
    ReSort(Context ctx, long obj)
    {
        super(ctx, obj);
    }
}
