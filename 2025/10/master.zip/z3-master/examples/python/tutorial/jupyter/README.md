# Jupyter version of the Z3 Python Tutorial.

Thanks to Peter Gragert, the Z3 tutorial guide is now available in the Jupyter notebook format. 

An online tutorial is available from https://github.com/philzook58/z3_tutorial
