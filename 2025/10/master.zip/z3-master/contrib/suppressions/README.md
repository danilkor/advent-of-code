# Suppression files

This directory contains suppression files used by various
program analysis tools.

Suppression files tell a program analysis tool to suppress
various warnings/errors.
